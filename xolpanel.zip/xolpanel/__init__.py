from telethon import *
import datetime as DT
from telethon import *
import requests,time,os,subprocess,re,sqlite3,sys,random,base64,json,math,logging,datetime,calendar,asyncio
from telethon import Button, events
from pathlib import Path
import datetime as DT
z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
def convert_bytes(bytes):
    bytes = int(bytes)
    if bytes < 1024:
        return f"{bytes}B"
    elif bytes < 1048576:
        return f"{(bytes + 1023)//1024}KB"
    elif bytes < 1073741824:
        return f"{(bytes + 1048575)//1048576}MB"
    else:
        return f"{(bytes + 1073741823)//1073741824}GB"

jh = f' ip -o $CMD -4 route show to default | awk \'{{print $5}}\''
INTERFACE = subprocess.check_output(jh, shell=True).decode("ascii")
dns = f'cat /etc/xray/dns'
ns = subprocess.check_output(dns, shell=True).decode("ascii").strip()
key = f'cat /etc/slowdns/server.pub'
pub = subprocess.check_output(key, shell=True).decode("ascii").strip()
logging.basicConfig(level=logging.INFO)
bot_start_time = datetime.datetime.now()
exec(open("xolpanel/var.txt","r").read())
bot = TelegramClient("XolPanel","6","eb06d4abfb49dc3eeb1aeb98ae0f581e").start(bot_token=BOT_TOKEN)
try:
    open("xolpanel/database.db")
except:
    x = sqlite3.connect("xolpanel/database.db")
    c = x.cursor()
    c.execute("CREATE TABLE admin (user_id)")
    for user_id in ADMIN:
        c.execute("INSERT INTO admin (user_id) VALUES (?)", (user_id,))
    x.commit()

def get_db():
	x = sqlite3.connect("xolpanel/database.db")
	x.row_factory = sqlite3.Row
	return x

def valid(id):
    if id in ADMIN:
        return "true"
    else:
        return "false"

def get_uptime():
    current_time = datetime.datetime.now()
    uptime = current_time - bot_start_time
    formatted_uptime = str(uptime).split('.')[0]  # Remove milliseconds
    return formatted_uptime

def convert_size(size_bytes):
   if size_bytes == 0:
       return "0B"
   size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
   i = int(math.floor(math.log(size_bytes, 1024)))
   p = math.pow(1024, i)
   s = round(size_bytes / p, 2)
   return "%s %s" % (s, size_name[i])

def vnstat_this_month_usage(interface_name):
    stdout = subprocess.getoutput(f"vnstat -s -i {interface_name} --json m")
    j = json.loads(stdout)
    interface = j['interfaces'][0]
    interface_name = interface['name']
    month = j['interfaces'][0]['traffic']['month'][-1]
    rx = month['rx']
    tx = month['tx']
    total = month['rx'] + month['tx']
    month_name = calendar.month_name[month['date']['month']]
    return interface_name, rx, tx, total, month_name

def human_bytes(B):
    """Return the given bytes as a human friendly KB, MB, GB, or TB string."""
    B = float(B)
    KB = float(1024)
    MB = float(KB ** 2)  # 1,048,576
    GB = float(KB ** 3)  # 1,073,741,824
    TB = float(KB ** 4)  # 1,099,511,627,776

    if B < KB:
        return '{0} {1}'.format(B,'Bytes' if 0 == B > 1 else 'Byte')
    elif KB <= B < MB:
        return '{0:.2f} KB'.format(B / KB)
    elif MB <= B < GB:
        return '{0:.2f} MB'.format(B / MB)
    elif GB <= B < TB:
        return '{0:.2f} GB'.format(B / GB)
    elif TB <= B:
        return '{0:.2f} TB'.format(B / TB)