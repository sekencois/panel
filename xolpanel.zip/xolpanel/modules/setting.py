from xolpanel import *
lin = f'cat /etc/xray/link'
link = subprocess.check_output(lin, shell=True).decode("ascii").strip()
@bot.on(events.CallbackQuery(data=b'rebotx'))
async def rebot_x(event):
  async def rebot_x_(event):
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚁𝚎𝚋𝚘𝚘𝚝 𝚂𝚎𝚛𝚟𝚎𝚛`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙`")
    msg = f"""
**◇──────────────────────◇***
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜𝚜 𝚁𝚎𝚋𝚘𝚘𝚝 𝚂𝚎𝚛𝚟𝚎𝚛 ⟩◇**
**◇──────────────────────◇**
**» 𝙳𝚊𝚕𝚊𝚖 𝚆𝚊𝚔𝚝𝚞 5 𝙳𝚎𝚝𝚒𝚔**
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.respond(msg)
    await asyncio.sleep(5)
    cmd = f'reboot'
    a = subprocess.check_output(cmd, shell=True).decode("utf-8")
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await rebot_x_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'speedx'))
async def speed_x(event):
  async def speed_x_(event):
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙶𝚎𝚝 𝚂𝚎𝚛𝚟𝚒𝚌𝚎 𝙸𝚗 𝚂𝚎𝚛𝚟𝚎𝚛`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙`")
    cmd = f'/usr/sbin/speedtest'
    try:
      x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
      print(x)
    except:
      await event.respond("** 𝚂𝚎𝚛𝚟𝚒𝚌𝚎 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      z = subprocess.check_output(cmd, shell=True).decode("utf-8") 
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚙𝚎𝚎𝚍 𝙸𝚗𝚏𝚘𝚛𝚖𝚊𝚝𝚒𝚘𝚗 ⟩◇**
**◇──────────────────────◇**
{z}
** » 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","setting")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await speed_x_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'runingx'))
async def runing_x(event):
  async def runing_x_(event):
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙶𝚎𝚝 𝚂𝚎𝚛𝚟𝚒𝚌𝚎 𝙸𝚗 𝚂𝚎𝚛𝚟𝚎𝚛`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙`")
    cmd = f'get-service status'
    try:
      x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
      print(x)
    except:
      await event.respond("** 𝚂𝚎𝚛𝚟𝚒𝚌𝚎 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      z = subprocess.check_output(cmd, shell=True).decode("utf-8") 
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚎𝚛𝚟𝚒𝚌𝚎 𝙸𝚗𝚏𝚘𝚛𝚖𝚊𝚝𝚒𝚘𝚗 ⟩◇**
**◇──────────────────────◇**
{z}
** » 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","setting")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await runing_x_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'resetx'))
async def reset_x(event):
  async def reset_x_(event):
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙶𝚎𝚝 𝚂𝚎𝚛𝚟𝚒𝚌𝚎 𝙸𝚗 𝚂𝚎𝚛𝚟𝚎𝚛`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙`")
    cmd = f'get-service restart'
    try:
      x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
      print(x)
    except:
      await event.respond("** 𝚂𝚎𝚛𝚟𝚒𝚌𝚎 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      z = subprocess.check_output(cmd, shell=True).decode("utf-8") 
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚁𝚎𝚜𝚝𝚊𝚛𝚝 𝚂𝚎𝚛𝚟𝚒𝚌𝚎 ⟩◇**
**◇──────────────────────◇**
{z}
** » 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","setting")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await reset_x_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'backupx'))
async def backup_x(event):
  async def backup_x_(event):
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙱𝚊𝚌𝚔𝚞𝚙 𝙳𝚊𝚝𝚊 𝚂𝚎𝚛𝚟𝚎𝚛`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙`")
    cmd = f'get-backres backup'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝙳𝚊𝚝𝚊 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      ip = requests.get(f"https://ipv4.icanhazip.com").text.strip()
      lin = f'cat /etc/xray/link'
      link = subprocess.check_output(lin, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝙱𝚊𝚌𝚔𝚞𝚙 𝙳𝚊𝚝𝚊 𝚂𝚎𝚛𝚟𝚎𝚛 ⟩◇**
**◇──────────────────────◇**
** » 𝙸𝙿 𝚅𝙿𝚂    :** `{ip}`
** » 𝙳𝙾𝙼𝙰𝙸𝙽    :** `{DOMAIN}`
** » 𝚉𝚘𝚗𝚎      :** `{z["timezone"]}`
** » 𝙸𝚂𝙿       :** `{z["isp"]}`
** » 𝙻𝙾𝙲𝙰𝚃𝙸𝙾𝙽  :** `{z["country"]}`
** » 🌀𝙻𝚒𝚗𝚔     :** **{link}**
** » 🤖@sshxvpn**
**◇──────────────────────◇**
** » 𝙿𝚕𝚎𝚊𝚜𝚎 𝚂𝚊𝚟𝚎 𝙻𝚒𝚗𝚔 𝙱𝚊𝚌𝚔𝚞𝚙**
"""
      await event.respond(msg)
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await backup_x_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'restorex'))
async def restore_x(event):
  async def restore_x_(event):
    async with bot.conversation(chat) as link:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚗𝚔 𝙱𝚊𝚌𝚔𝚞𝚙 : **")
      link = link.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      link = (await link).raw_text
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚁𝚎𝚜𝚝𝚘𝚛𝚎 𝙳𝚊𝚝𝚊 𝚂𝚎𝚛𝚟𝚎𝚛`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙`")
    cmd = f'printf "%s\n" "{link}" | get-backres restore'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝙳𝚊𝚝𝚊 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      ip = requests.get(f"https://ipv4.icanhazip.com").text.strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚁𝚎𝚜𝚝𝚘𝚛𝚎 𝙳𝚊𝚝𝚊 𝚂𝚎𝚛𝚟𝚎𝚛 ⟩◇**
**◇──────────────────────◇**
** » 𝙸𝙿 𝚅𝙿𝚂    :** `{ip}`
** » 𝙳𝙾𝙼𝙰𝙸𝙽    :** `{DOMAIN}`
** » 𝚉𝚘𝚗𝚎      :** `{z["timezone"]}`
** » 𝙸𝚂𝙿       :** `{z["isp"]}`
** » 𝙻𝙾𝙲𝙰𝚃𝙸𝙾𝙽  :** `{z["country"]}`
** » 🌀𝙻𝚒𝚗𝚔     :** **{link}**
** » 🤖@sshxvpn**
**◇──────────────────────◇**
** » 𝙿𝚕𝚎𝚊𝚜𝚎 𝚁𝚎𝚜𝚝𝚊𝚛𝚝 𝚂𝚎𝚛𝚟𝚒𝚌𝚎**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","backer")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await restore_x_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
  async def backers_(event):
    inline = [
[Button.inline(" [ 𝘽𝙖𝙘𝙠𝙪𝙥 𝘿𝙖𝙩𝙖 ] ","backupx"),
Button.inline(" [ 𝙍𝙚𝙨𝙩𝙤𝙧𝙚 𝘿𝙖𝙩𝙖 ]","restorex")],
[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","setting")]]
    msg = f"""
**◇──────────────────────◇**
**      ◇⟨ 𝙱𝙰𝙲𝙺𝚄𝙿 & 𝚁𝙴𝚂𝚃𝙾𝚁𝙴 ⟩◇**
**◇──────────────────────◇**
**» 𝙳𝚘𝚖𝚊𝚒𝚗   :** `{DOMAIN}`
**» 𝙸𝚂𝙿 𝚅𝙿𝚂  :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢  :** `{z["country"]}`
**» 𝙻𝚊𝚜𝚝 𝙱𝚊𝚌𝚔𝚞𝚙  :** `{link}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await backers_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)


@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
  async def settings_(event):
    inline = [
[Button.inline("[ 𝘽𝙖𝙘𝙠𝙪𝙥 & 𝙍𝙚𝙨𝙩𝙤𝙧𝙚 ]","backer"),
Button.inline("[ 𝙎𝙥𝙚𝙚𝙙𝙩𝙚𝙨𝙩 ]","speedx")],
[Button.inline("[ 𝙍𝙪𝙣𝙣𝙞𝙣𝙜 𝙎𝙚𝙧𝙫𝙞𝙘𝙚 ]","runingx"),
Button.inline("[ 𝙍𝙚𝙨𝙩𝙖𝙧𝙩 𝙎𝙚𝙧𝙫𝙞𝙘𝙚 ]","resetx")],
[Button.inline("[ 𝙍𝙚𝙗𝙤𝙤𝙩 𝙎𝙚𝙧𝙫𝙚𝙧 ]","rebootx")],
[Button.inline(" ‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 › ","menu")]]
    msg = f"""
**◇──────────────────────◇**
**      ◇⟨ 𝙾𝚃𝙷𝙴𝚁 𝚂𝙴𝚃𝚃𝙸𝙽𝙶𝚂 ⟩◇**
**◇──────────────────────◇**
**» 𝙳𝚘𝚖𝚊𝚒𝚗   :** `{DOMAIN}`
**» 𝙸𝚂𝙿 𝚅𝙿𝚂  :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢  :** `{z["country"]}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await settings_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
