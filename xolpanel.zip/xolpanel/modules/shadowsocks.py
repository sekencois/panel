from xolpanel import *
  
@bot.on(events.CallbackQuery(data=b'create-shadowsocks-all'))
async def create_shadowsocks_all(event):
  async def create_shadowsocks_all_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as pw:
      await event.respond("** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝚀𝚞𝚘𝚝𝚊 [𝙶𝙱] ( 𝚖𝚊𝚡 𝟺 𝚍𝚒𝚐𝚒𝚝𝚜 𝚗𝚞𝚖𝚋𝚎𝚛 ) : **")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
      if not (1 <= len(pw) <= 4):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond("** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | ass bot_add all'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝 **")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      b = [x.group() for x in re.finditer("ss://(.*)",a)]
      print(b)
      uid_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $5}}\''
      uuid = subprocess.check_output(uid_command, shell=True).decode("ascii").strip()
      iplim_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $2}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      quota_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $4}}\''
      pw1 = subprocess.check_output(quota_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨  𝚇𝚛𝚊𝚢/𝚂_𝚜𝚘𝚌𝚔𝚜 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚁𝚎𝚖𝚊𝚛𝚔𝚜      :** `{user}`
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛     :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢      :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**» 𝚄𝚜𝚎𝚛 𝚀𝚞𝚘𝚝𝚊   :** `{pw1} GB`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜 :** `{ip1} IP`
**» 𝙿𝚘𝚛𝚝 𝚃𝙻𝚂     :** `443`
**» 𝙿𝚘𝚛𝚝 𝙽𝚃𝙻𝚂    :** `80`
**» 𝙿𝚘𝚛𝚝 𝙶𝚁𝙿𝙲    :** `443`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{uuid}`
**» 𝙲𝚑𝚒𝚙𝚎𝚛𝚜       :** `chacha20-ietf-poly1305`
**» 𝙽𝚎𝚝𝚆𝚘𝚛𝚔      :** `(WS) or (gRPC)`
**» 𝙿𝚊𝚝𝚌𝚑         :** `/shadowsocks`
**» 𝙿𝚊𝚝𝚌𝚑 𝙳𝚢𝚗𝚊𝚖𝚒𝚌 :** `http://BUG.COM`
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎𝙽𝚊𝚖𝚎  :** `shadowsocks-grpc`
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝚃𝙻𝚂     :** 
```{b[0].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙽𝚃𝙻𝚂    :** 
```{b[1].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙶𝚁𝙿𝙲    :** 
```{b[2].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 :**
**https://{DOMAIN}:81/ss-{user}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{later}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_shadowsocks_all_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'create-shadowsocks-ws'))
async def create_shadowsocks_ws(event):
  async def create_shadowsocks_ws_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as pw:
      await event.respond("** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝚀𝚞𝚘𝚝𝚊 [𝙶𝙱] ( 𝚖𝚊𝚡 𝟺 𝚍𝚒𝚐𝚒𝚝𝚜 𝚗𝚞𝚖𝚋𝚎𝚛 ) : **")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
      if not (1 <= len(pw) <= 4):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond("** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | ass bot_add ws'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝 **")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      b = [x.group() for x in re.finditer("ss://(.*)",a)]
      print(b)
      uid_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $5}}\''
      uuid = subprocess.check_output(uid_command, shell=True).decode("ascii").strip()
      iplim_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $2}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      quota_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $4}}\''
      pw1 = subprocess.check_output(quota_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨  𝚇𝚛𝚊𝚢/𝚂_𝚜𝚘𝚌𝚔𝚜 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚁𝚎𝚖𝚊𝚛𝚔𝚜      :** `{user}`
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛     :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢      :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**» 𝚄𝚜𝚎𝚛 𝚀𝚞𝚘𝚝𝚊   :** `{pw1} GB`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜 :** `{ip1} IP`
**» 𝙿𝚘𝚛𝚝 𝚃𝙻𝚂     :** `443`
**» 𝙿𝚘𝚛𝚝 𝙽𝚃𝙻𝚂    :** `80`
**» 𝙿𝚘𝚛𝚝 𝙶𝚁𝙿𝙲    :** `443`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{uuid}`
**» 𝙲𝚑𝚒𝚙𝚎𝚛𝚜       :** `chacha20-ietf-poly1305`
**» 𝙽𝚎𝚝𝚆𝚘𝚛𝚔      :** `(WS) or (gRPC)`
**» 𝙿𝚊𝚝𝚌𝚑         :** `/shadowsocks`
**» 𝙿𝚊𝚝𝚌𝚑 𝙳𝚢𝚗𝚊𝚖𝚒𝚌 :** `http://BUG.COM`
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎𝙽𝚊𝚖𝚎  :** `shadowsocks-grpc`
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝚃𝙻𝚂     :** 
```{b[0].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙽𝚃𝙻𝚂    :** 
```{b[1].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 :**
**https://{DOMAIN}:81/ss-{user}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{later}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_shadowsocks_ws_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'create-shadowsocks-grpc'))
async def create_shadowsocks_grpc(event):
  async def create_shadowsocks_grpc_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as pw:
      await event.respond("** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝚀𝚞𝚘𝚝𝚊 [𝙶𝙱] ( 𝚖𝚊𝚡 𝟺 𝚍𝚒𝚐𝚒𝚝𝚜 𝚗𝚞𝚖𝚋𝚎𝚛 ) : **")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
      if not (1 <= len(pw) <= 4):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond("** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{user}" "{exp}" "{pw}" "{ip}" | ass bot_add grpc'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝 **")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      b = [x.group() for x in re.finditer("ss://(.*)",a)]
      print(b)
      uid_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $5}}\''
      uuid = subprocess.check_output(uid_command, shell=True).decode("ascii").strip()
      iplim_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $2}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      quota_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $4}}\''
      pw1 = subprocess.check_output(quota_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨  𝚇𝚛𝚊𝚢/𝚂_𝚜𝚘𝚌𝚔𝚜 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚁𝚎𝚖𝚊𝚛𝚔𝚜      :** `{user}`
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛     :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢      :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**» 𝚄𝚜𝚎𝚛 𝚀𝚞𝚘𝚝𝚊   :** `{pw1} GB`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜 :** `{ip1} IP`
**» 𝙿𝚘𝚛𝚝 𝚃𝙻𝚂     :** `443`
**» 𝙿𝚘𝚛𝚝 𝙽𝚃𝙻𝚂    :** `80`
**» 𝙿𝚘𝚛𝚝 𝙶𝚁𝙿𝙲    :** `443`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{uuid}`
**» 𝙲𝚑𝚒𝚙𝚎𝚛𝚜       :** `chacha20-ietf-poly1305`
**» 𝙽𝚎𝚝𝚆𝚘𝚛𝚔      :** `(WS) or (gRPC)`
**» 𝙿𝚊𝚝𝚌𝚑         :** `/shadowsocks`
**» 𝙿𝚊𝚝𝚌𝚑 𝙳𝚢𝚗𝚊𝚖𝚒𝚌 :** `http://BUG.COM`
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎𝙽𝚊𝚖𝚎  :** `shadowsocks-grpc`
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙶𝚁𝙿𝙲    :** 
```{b[0].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 :**
**https://{DOMAIN}:81/ss-{user}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{later}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_shadowsocks_grpc_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'triall-shadowsocks-all'))
async def triall_shadowsocks_all(event):
  async def triall_shadowsocks_all_(event):
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙳𝚞𝚛𝚊𝚝𝚒𝚘𝚗 [ 𝙴𝚡𝚊𝚖𝚙𝚕𝚎 : 1m / 1h ] : **")
      exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      exp = (await exp).raw_text
      if not (1 <= len(exp) <= 3):
         await event.edit("e.g., m 𝚏𝚘𝚛 𝚖𝚒𝚗𝚞𝚝𝚎𝚜, h 𝚏𝚘𝚛 𝚑𝚘𝚞𝚛𝚜", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "vless")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝚃𝚛𝚒𝚊𝚕𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" "{ip}" | ass bot_triall all'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝**")
    else:
      b = [x.group() for x in re.finditer("ss://(.*)",a)]
      print(b)
      remarks = re.search("#(.*)",b[3]).group(1)
      uid_command = f'cat "/etc/shadowsocks/{remarks}" | awk \'{{print $5}}\''
      uuid = subprocess.check_output(uid_command, shell=True).decode("ascii").strip()
      exp1 = re.search("ss://(.*)#",b[3]).group(1)
      iplim_command = f'cat "/etc/shadowsocks/{remarks}" | awk \'{{print $2}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      quota_command = f'cat "/etc/shadowsocks/{remarks}" | awk \'{{print $4}}\''
      pw1 = subprocess.check_output(quota_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨  𝚇𝚛𝚊𝚢/𝚂_𝚜𝚘𝚌𝚔𝚜 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚁𝚎𝚖𝚊𝚛𝚔𝚜      :** `{remarks}`
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛     :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢      :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**» 𝚄𝚜𝚎𝚛 𝚀𝚞𝚘𝚝𝚊   :** `{pw1} GB`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜 :** `{ip1} IP`
**» 𝙿𝚘𝚛𝚝 𝚃𝙻𝚂     :** `443`
**» 𝙿𝚘𝚛𝚝 𝙽𝚃𝙻𝚂    :** `80`
**» 𝙿𝚘𝚛𝚝 𝙶𝚁𝙿𝙲    :** `443`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{uuid}`
**» 𝙲𝚑𝚒𝚙𝚎𝚛𝚜       :** `chacha20-ietf-poly1305`
**» 𝙽𝚎𝚝𝚆𝚘𝚛𝚔      :** `(WS) or (gRPC)`
**» 𝙿𝚊𝚝𝚌𝚑         :** `/shadowsocks`
**» 𝙿𝚊𝚝𝚌𝚑 𝙳𝚢𝚗𝚊𝚖𝚒𝚌 :** `http://BUG.COM`
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎𝙽𝚊𝚖𝚎  :** `shadowsocks-grpc`
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝚃𝙻𝚂     :** 
```{b[0].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙽𝚃𝙻𝚂    :** 
```{b[1].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙶𝚁𝙿𝙲    :** 
```{b[2].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 :**
**https://{DOMAIN}:81/ss-{remarks}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await triall_shadowsocks_all_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'triall-shadowsocks-ws'))
async def triall_shadowsocks_ws(event):
  async def triall_shadowsocks_ws_(event):
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙳𝚞𝚛𝚊𝚝𝚒𝚘𝚗 [ 𝙴𝚡𝚊𝚖𝚙𝚕𝚎 : 1m / 1h ] : **")
      exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      exp = (await exp).raw_text
      if not (1 <= len(exp) <= 3):
         await event.edit("e.g., m 𝚏𝚘𝚛 𝚖𝚒𝚗𝚞𝚝𝚎𝚜, h 𝚏𝚘𝚛 𝚑𝚘𝚞𝚛𝚜", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "vless")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝚃𝚛𝚒𝚊𝚕𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" "{ip}" | ass bot_triall ws'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝**")
    else:
      b = [x.group() for x in re.finditer("ss://(.*)",a)]
      print(b)
      remarks = re.search("#(.*)",b[2]).group(1)
      uid_command = f'cat "/etc/shadowsocks/{remarks}" | awk \'{{print $5}}\''
      uuid = subprocess.check_output(uid_command, shell=True).decode("ascii").strip()
      exp1 = re.search("ss://(.*)#",b[2]).group(1)
      iplim_command = f'cat "/etc/shadowsocks/{remarks}" | awk \'{{print $2}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      quota_command = f'cat "/etc/shadowsocks/{remarks}" | awk \'{{print $4}}\''
      pw1 = subprocess.check_output(quota_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨  𝚇𝚛𝚊𝚢/𝚂_𝚜𝚘𝚌𝚔𝚜 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚁𝚎𝚖𝚊𝚛𝚔𝚜      :** `{remarks}`
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛     :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢      :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**» 𝚄𝚜𝚎𝚛 𝚀𝚞𝚘𝚝𝚊   :** `{pw1} GB`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜 :** `{ip1} IP`
**» 𝙿𝚘𝚛𝚝 𝚃𝙻𝚂     :** `443`
**» 𝙿𝚘𝚛𝚝 𝙽𝚃𝙻𝚂    :** `80`
**» 𝙿𝚘𝚛𝚝 𝙶𝚁𝙿𝙲    :** `443`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{uuid}`
**» 𝙲𝚑𝚒𝚙𝚎𝚛𝚜       :** `chacha20-ietf-poly1305`
**» 𝙽𝚎𝚝𝚆𝚘𝚛𝚔      :** `(WS) or (gRPC)`
**» 𝙿𝚊𝚝𝚌𝚑         :** `/shadowsocks`
**» 𝙿𝚊𝚝𝚌𝚑 𝙳𝚢𝚗𝚊𝚖𝚒𝚌 :** `http://BUG.COM`
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎𝙽𝚊𝚖𝚎  :** `shadowsocks-grpc`
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝚃𝙻𝚂     :** 
```{b[0].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙽𝚃𝙻𝚂    :** 
```{b[1].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 :**
**https://{DOMAIN}:81/ss-{remarks}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await triall_shadowsocks_ws_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'triall-shadowsocks-grpc'))
async def triall_shadowsocks_grpc(event):
  async def triall_shadowsocks_grpc_(event):
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙳𝚞𝚛𝚊𝚝𝚒𝚘𝚗 [ 𝙴𝚡𝚊𝚖𝚙𝚕𝚎 : 1m / 1h ] : **")
      exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      exp = (await exp).raw_text
      if not (1 <= len(exp) <= 3):
         await event.edit("e.g., m 𝚏𝚘𝚛 𝚖𝚒𝚗𝚞𝚝𝚎𝚜, h 𝚏𝚘𝚛 𝚑𝚘𝚞𝚛𝚜", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "vless")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝚃𝚛𝚒𝚊𝚕𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" "{ip}" | ass bot_triall grpc'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝**")
    else:
      b = [x.group() for x in re.finditer("ss://(.*)",a)]
      print(b)
      remarks = re.search("#(.*)",b[1]).group(1)
      uid_command = f'cat "/etc/shadowsocks/{remarks}" | awk \'{{print $5}}\''
      uuid = subprocess.check_output(uid_command, shell=True).decode("ascii").strip()
      exp1 = re.search("ss://(.*)#",b[1]).group(1)
      iplim_command = f'cat "/etc/shadowsocks/{remarks}" | awk \'{{print $2}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      quota_command = f'cat "/etc/shadowsocks/{remarks}" | awk \'{{print $4}}\''
      pw1 = subprocess.check_output(quota_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨  𝚇𝚛𝚊𝚢/𝚂_𝚜𝚘𝚌𝚔𝚜 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚁𝚎𝚖𝚊𝚛𝚔𝚜      :** `{remarks}`
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛     :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢      :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**» 𝚄𝚜𝚎𝚛 𝚀𝚞𝚘𝚝𝚊   :** `{pw1} GB`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜 :** `{ip1} IP`
**» 𝙿𝚘𝚛𝚝 𝚃𝙻𝚂     :** `443`
**» 𝙿𝚘𝚛𝚝 𝙽𝚃𝙻𝚂    :** `80`
**» 𝙿𝚘𝚛𝚝 𝙶𝚁𝙿𝙲    :** `443`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{uuid}`
**» 𝙲𝚑𝚒𝚙𝚎𝚛𝚜       :** `chacha20-ietf-poly1305`
**» 𝙽𝚎𝚝𝚆𝚘𝚛𝚔      :** `(WS) or (gRPC)`
**» 𝙿𝚊𝚝𝚌𝚑         :** `/shadowsocks`
**» 𝙿𝚊𝚝𝚌𝚑 𝙳𝚢𝚗𝚊𝚖𝚒𝚌 :** `http://BUG.COM`
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎𝙽𝚊𝚖𝚎  :** `shadowsocks-grpc`
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙶𝚁𝙿𝙲    :** 
```{b[2].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 :**
**https://{DOMAIN}:81/ss-{remarks}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await triall_shadowsocks_grpc_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'cek-shadowsocks'))
async def cek_shadowsocks(event):
  async def cek_shadowsocks_(event):
    shadowsocks_data_cmd = "cat /etc/shadowsocks/.shadowsocks.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(shadowsocks_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/shadowsocks/{akun} | awk '{{print $6}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
        exp_cmd = f'cat /etc/shadowsocks/.shadowsocks.db | grep "{akun}" | cut -d " " -f 3'
        exp1 = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        result_message += f"  {formatted_akun}   -   {exp1}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝙴𝚡𝚙𝚒𝚛𝚎𝚍**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    cmd = f'ass bot_check {user}'
    a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    b = [x.group() for x in re.finditer("ss://(.*)",a)]
    print(b)
    exp_cmd = f'cat /etc/shadowsocks/.shadowsocks.db | grep "{user}" | cut -d " " -f 3'
    iplim_cmd = f"cat /etc/shadowsocks/{user} | awk '{{print $2}}'"
    lim_cmd = f"cat /etc/shadowsocks/{user} | awk '{{print $4}}'"
    uid_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $5}}\''
    uuid = subprocess.check_output(uid_command, shell=True).decode("ascii").strip() 
    exp1 = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
    ip1 = subprocess.check_output(iplim_cmd, shell=True, text=True).strip()
    pw1 = subprocess.check_output(lim_cmd, shell=True, text=True).strip()
    kategori_pengguna = subprocess.check_output(['cat', f'/etc/shadowsocks/{user}']).decode().split()[2]

    # Melakukan tindakan berdasarkan kategori pengguna
    if kategori_pengguna == "all":
        link = f"""
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝚃𝙻𝚂     :** 
```{b[0].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙽𝚃𝙻𝚂    :** 
```{b[1].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙶𝚁𝙿𝙲    :** 
```{b[2].strip("'").replace(" ","")}```
**◇──────────────────────◇**
"""
    elif kategori_pengguna == "ws":
        link = f"""
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝚃𝙻𝚂     :** 
```{b[0].strip("'").replace(" ","")}```
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙽𝚃𝙻𝚂    :** 
```{b[1].strip("'").replace(" ","")}```
**◇──────────────────────◇**
"""
    elif kategori_pengguna == "grpc":
        link = f"""
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙶𝚁𝙿𝙲    :** 
```{b[0].strip("'").replace(" ","")}```
**◇──────────────────────◇**
"""
    msg = f"""
**◇──────────────────────◇**
**     ◇⟨  𝚇𝚛𝚊𝚢/𝚂_𝚜𝚘𝚌𝚔𝚜 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚁𝚎𝚖𝚊𝚛𝚔𝚜      :** `{user}`
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛     :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢      :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**» 𝚄𝚜𝚎𝚛 𝚀𝚞𝚘𝚝𝚊   :** `{pw1} GB`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜 :** `{ip1} IP`
**» 𝙿𝚘𝚛𝚝 𝚃𝙻𝚂     :** `443`
**» 𝙿𝚘𝚛𝚝 𝙽𝚃𝙻𝚂    :** `80`
**» 𝙿𝚘𝚛𝚝 𝙶𝚁𝙿𝙲    :** `443`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{uuid}`
**» 𝙲𝚑𝚒𝚙𝚎𝚛𝚜       :** `chacha20-ietf-poly1305`
**» 𝙽𝚎𝚝𝚆𝚘𝚛𝚔      :** `(WS) or (gRPC)`
**» 𝙿𝚊𝚝𝚌𝚑         :** `/shadowsocks`
**» 𝙿𝚊𝚝𝚌𝚑 𝙳𝚢𝚗𝚊𝚖𝚒𝚌 :** `http://BUG.COM`
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎𝙽𝚊𝚖𝚎  :** `shadowsocks-grpc`
{link}
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝     :**
**https://{DOMAIN}:81/shadowsocks-{user}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚑𝚎𝚌𝚔 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
    
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await cek_shadowsocks_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

#Login shadowsocks
@bot.on(events.CallbackQuery(data=b'login-shadowsocks'))
async def login_shadowsocks(event):
  async def login_shadowsocks_(event):
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = 'shadowsocks login'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""
{z}
""",buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await login_shadowsocks_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'delete-shadowsocks'))
async def delete_shadowsocks(event):
  async def delete_shadowsocks_(event):
    shadowsocks_data_cmd = "cat /etc/shadowsocks/.shadowsocks.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(shadowsocks_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/shadowsocks/{akun} | awk '{{print $6}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
        exp_cmd = f'cat /etc/shadowsocks/.shadowsocks.db | grep "{akun}" | cut -d " " -f 3'
        exp1 = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        result_message += f"  {formatted_akun}   -   {exp1}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝙴𝚡𝚙𝚒𝚛𝚎𝚍**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    await event.edit("`Processing Deleted Premium Account`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'ktriall ss {user}'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      msg = f"""
**◇──────────────────────◇**
** ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝙳𝚎𝚕𝚎𝚝𝚎 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await delete_shadowsocks_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'renew-shadowsocks-all'))
async def ren_shadowsocks_all(event):
  async def ren_shadowsocks_all_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as pw:
      await event.respond("** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝚀𝚞𝚘𝚝𝚊 [𝙶𝙱] ( 𝚖𝚊𝚡 𝟺 𝚍𝚒𝚐𝚒𝚝𝚜 𝚗𝚞𝚖𝚋𝚎𝚛 ) : **")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
      if not (1 <= len(pw) <= 4):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚙𝚍𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" "{pw}" "{ip}" | ass renew {user} all'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond(f"** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      exp_command = f'cat /etc/shadowsocks/.shadowsocks.db | grep "{user}" | cut -d " " -f 3'
      exp1 = subprocess.check_output(exp_command, shell=True).decode("ascii").strip()
      iplim_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $2}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      quota_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $4}}\''
      pw1 = subprocess.check_output(quota_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚁𝚎𝚗𝚎𝚠 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 𝚀𝚞𝚘𝚝𝚊 :** `{pw1} 𝙶𝙱 `
**» 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 :** `{ip1} 𝙸𝙿`
**» 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙾𝚗 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_shadowsocks_all_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'renew-shadowsocks-exp'))
async def ren_shadowsocks_exp(event):
  async def ren_shadowsocks_exp_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚙𝚍𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" | ass renew {user} exp'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond(f"** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      exp_command = f'cat /etc/shadowsocks/.shadowsocks.db | grep "{user}" | cut -d " " -f 3'
      exp1 = subprocess.check_output(exp_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚁𝚎𝚗𝚎𝚠 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙾𝚗 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_shadowsocks_exp_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
 
@bot.on(events.CallbackQuery(data=b'renew-shadowsocks-lim'))
async def ren_shadowsocks_db(event):
  async def ren_shadowsocks_db_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as pw:
      await event.respond("** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝚀𝚞𝚘𝚝𝚊 [𝙶𝙱] ( 𝚖𝚊𝚡 𝟺 𝚍𝚒𝚐𝚒𝚝𝚜 𝚗𝚞𝚖𝚋𝚎𝚛 ) : **")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
      if not (1 <= len(pw) <= 4):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚙𝚍𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{pw}" "{ip}" | ass renew {user} db'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond(f"** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      iplim_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $2}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      quota_command = f'cat "/etc/shadowsocks/{user}" | awk \'{{print $4}}\''
      pw1 = subprocess.check_output(quota_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚁𝚎𝚗𝚎𝚠 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 𝚀𝚞𝚘𝚝𝚊 :** `{pw1} 𝙶𝙱 `
**» 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 :** `{ip1} 𝙸𝙿`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_shadowsocks_db_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'lok-shadowsocks'))
async def lok_shadowsocks(event):
  async def lok_shadowsocks_(event):
    shadowsocks_data_cmd = "cat /etc/shadowsocks/.shadowsocks.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(shadowsocks_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/shadowsocks/{akun} | awk '{{print $6}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        formatted_status = f"{status: <{5}}"
        result_message += f"  {formatted_akun}   -   {formatted_status}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝚂𝚝𝚊𝚝𝚞𝚜**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙻𝚘𝚌𝚔𝚎𝚍 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'ass lock {user}'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝙻𝚘𝚌𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await lok_shadowsocks_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
    
@bot.on(events.CallbackQuery(data=b'unlok-shadowsocks'))
async def unlok_shadowsocks(event):
  async def unlok_shadowsocks_(event):
    shadowsocks_data_cmd = "cat /etc/shadowsocks/.shadowsocks.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(shadowsocks_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/shadowsocks/{akun} | awk '{{print $6}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        formatted_status = f"{status: <{5}}"
        result_message += f"  {formatted_akun}   -   {formatted_status}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝚂𝚝𝚊𝚝𝚞𝚜**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "shadowsocks")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚗𝚕𝚘𝚌𝚔𝚎𝚍 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'ass unlock {user}'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚄𝚗𝚕𝚘𝚌𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await unlok_shadowsocks_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'create-shadowsocks'))
async def create_shadowsocks(event):
  async def create_shadowsocks_(event):
    inline = [
[Button.inline(" 𝘾𝙧𝙚𝙖𝙩𝙚 𝙒𝙎 ","create-shadowsocks-ws"),
Button.inline(" 𝘾𝙧𝙚𝙖𝙩𝙚 𝙜𝙍𝙋𝘾 ","create-shadowsocks-grpc")],
[Button.inline(" 𝘾𝙧𝙚𝙖𝙩𝙚 𝘼𝙡𝙡 ( 𝙒𝙎 & 𝙜𝙍𝙋𝘾 )","create-shadowsocks-all")],
[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]]
    msg = f"""
**◇──────────────────────◇**
** 𝙲𝚕𝚒𝚎𝚗𝚝 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : mehonk76 )**
** 𝙻𝚒𝚖𝚒𝚝 𝚀𝚞𝚘𝚝𝚊 ( 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 1000 )**
** 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜 ( 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : '100' )**
** 𝙸𝚗𝚙𝚞𝚝 0 𝙵𝚘𝚛 𝚀𝚞𝚘𝚝𝚊 '9999' [GB]**
** 𝙸𝚗𝚙𝚞𝚝 0 𝙵𝚘𝚛 𝙰𝚍𝚛𝚎𝚜𝚜 '999' [𝙸𝙿]**
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_shadowsocks_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'triall-shadowsocks'))
async def triall_shadowsocks(event):
  async def triall_shadowsocks_(event):
    inline = [
[Button.inline(" 𝙏𝙧𝙞𝙖𝙡𝙡 𝙒𝙎 ","triall-shadowsocks-ws"),
Button.inline(" 𝙏𝙧𝙞𝙖𝙡𝙡 𝙜𝙍𝙋𝘾 ","triall-shadowsocks-grpc")],
[Button.inline(" 𝙏𝙧𝙞𝙖𝙡𝙡 𝘼𝙡𝙡 ( 𝙒𝙎 & 𝙜𝙍𝙋𝘾 )","triall-shadowsocks-all")],
[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]]
    msg = f"""
**◇──────────────────────◇**
** 𝚄𝚜𝚎 'm' 𝚏𝚘𝚛 𝚖𝚒𝚗𝚞𝚝𝚎𝚜, 'h' 𝚏𝚘𝚛 𝚑𝚘𝚞𝚛𝚜 **
** 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 ( 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : '100' )**
** 𝙸𝚗𝚙𝚞𝚝 0 𝙵𝚘𝚛 𝙸𝙿 '999' [𝙸𝙿]**
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await triall_shadowsocks_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'renew-shadowsocks'))
async def renew_shadowsocks(event):
  async def renew_shadowsocks_(event):
    inline = [
[Button.inline(" 𝙍𝙚𝙣𝙚𝙬 𝙀𝙭𝙥 ","renew-shadowsocks-exp"),
Button.inline(" 𝙍𝙚𝙣𝙚𝙬 𝙇𝙞𝙢𝙞𝙩 ","renew-shadowsocks-lim")],
[Button.inline(" 𝙍𝙚𝙣𝙚𝙬 𝘼𝙡𝙡 ( 𝙀𝙭𝙥 & 𝙇𝙞𝙢𝙞𝙩 )","renew-shadowsocks-all")],
[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","shadowsocks")]]
    
    shadowsocks_data_cmd = "cat /etc/shadowsocks/.shadowsocks.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(shadowsocks_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        exp_cmd = f'cat /etc/shadowsocks/.shadowsocks.db | grep "{akun}" | cut -d " " -f 3'
        iplim_cmd = f"cat /etc/shadowsocks/{akun} | awk '{{print $2}}'"
        lim_cmd = f"cat /etc/shadowsocks/{akun} | awk '{{print $4}}'"          
        exp = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
        iplim = subprocess.check_output(iplim_cmd, shell=True, text=True).strip()
        lim = subprocess.check_output(lim_cmd, shell=True, text=True).strip()              
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        formatted_lim = f"{lim: <{4}}"
        formatted_iplim = f"{iplim: <{3}}"
        result_message += f"  {formatted_akun}  -  {exp}  -  {formatted_lim} GB  -  {formatted_iplim} IP\n"
        await asyncio.sleep(0.2)  # Sleep for 0.2 seconds 
        # Kirim pesan dengan hasil yang dikumpulkan
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎   |   𝙴𝚡𝚙   |  Quota  |  𝙸𝙿**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(2)
      await event.edit(msg, buttons=inline)   
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)

  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
     await renew_shadowsocks_(event)
  else:
     await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'shadowsocks'))
async def shadowsocks(event):
  async def shadowsocks_(event):
    inline = [
[Button.inline("[ 𝘾𝙧𝙚𝙖𝙩𝙚 𝙎_𝙨𝙤𝙘𝙠𝙨 ]","create-shadowsocks"),
Button.inline("[ 𝙏𝙧𝙞𝙖𝙡𝙡 𝙎_𝙨𝙤𝙘𝙠𝙨 ]","triall-shadowsocks")],
[Button.inline("[ 𝘿𝙚𝙡𝙚𝙩𝙚 𝙎_𝙨𝙤𝙘𝙠𝙨 ]","delete-shadowsocks"),
Button.inline("[ 𝙍𝙚𝙣𝙚𝙬 𝙎_𝙨𝙤𝙘𝙠𝙨 ]","renew-shadowsocks")],
[Button.inline("[ 𝙇𝙤𝙘𝙠 𝙎_𝙨𝙤𝙘𝙠𝙨 ]","lok-shadowsocks"),
Button.inline("[ 𝙐𝙣𝙡𝙤𝙘𝙠 𝙎_𝙨𝙤𝙘𝙠𝙨 ]","unlok-shadowsocks")],
[Button.inline("[ 𝘾𝙝𝙚𝙘𝙠 𝙎_𝙨𝙤𝙘𝙠𝙨 ]","cek-shadowsocks"),
Button.inline("[ 𝙇𝙤𝙜𝙞𝙣 𝙎_𝙨𝙤𝙘𝙠𝙨 ]","login-shadowsocks")],
[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","menu")]]
    msg = f"""
**◇──────────────────────◇**
**         ◇⟨ 𝚂_𝚂𝙾𝙲𝙺𝚂 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 ⟩◇**
**◇──────────────────────◇**
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎   :** `𝚇𝚁𝙰𝚈 𝚂𝙷𝙰𝙳𝙾𝚆𝚂𝙾𝙲𝙺𝚂`
**» 𝙳𝚘𝚖𝚊𝚒𝚗   :** `{DOMAIN}`
**» 𝙸𝚂𝙿 𝚅𝙿𝚂  :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢  :** `{z["country"]}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await shadowsocks_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
