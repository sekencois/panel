from xolpanel import *

#CRATE SSH
@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
  async def create_ssh_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    async with bot.conversation(chat) as pw:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
      if not (2 <= len(pw) <= 8):
         await event.respond(f" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond("** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("` 𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" "{ip}" | assh bot_add'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝**")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨ 𝚂𝚂𝙷 𝙾𝚙𝚎𝚗𝚅𝙿𝙽 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     :** `{user}`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{pw}`
**◇──────────────────────◇**
**» 🌀𝚄𝙳𝙿 𝙰𝚌𝚌𝚘𝚞𝚗𝚝   :**
`{DOMAIN}:54-65535@{user}:{pw}`
**» 🌀𝚆𝚂𝚂 𝙰𝚌𝚌𝚘𝚞𝚗𝚝  :**
`{DOMAIN}:80@{user}:{pw}`
**◇──────────────────────◇** 
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛           :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢             :** `{z["country"]}`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜        :** `{ip} IP`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗       :** `{DOMAIN}`
**» 𝙷𝚘𝚜𝚝 𝙽𝚂𝙳𝚘𝚖𝚊𝚒𝚗  :** `{ns}`
**» 𝙿𝚞𝚋 𝙺𝚎𝚢               :** `{pub}`
**◇──────────────────────◇**
**» 𝙿𝚘𝚛𝚝 𝚄𝙳𝙿 𝙲𝚞𝚜𝚝𝚘𝚖    :** `54-65535` 
**» 𝙿𝚘𝚛𝚝 𝚂𝚂𝙻 𝚃𝙻𝚂/𝚂𝙽𝙸    :** `443` 
**» 𝙿𝚘𝚛𝚝 𝚆𝚂𝚂 𝙽𝚃𝙻𝚂        :** `80, 8080`
**» 𝙿𝚘𝚛𝚝 𝙾𝚅𝙿𝙽                :** `443, 1194, 2200`
**» 𝙿𝚛𝚘𝚡𝚢 𝚂𝚚𝚞𝚒𝚍              :** `3128`
**» 𝙱𝚊𝚍𝚅𝙿𝙽 𝚄𝙳𝙿            :** `7100-7300`
**◇──────────────────────◇**
**⟨ 𝙿𝚊𝚢𝚕𝚘𝚊𝚍 𝚆𝚂  ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**◇──────────────────────◇**
**» 🌀𝙾𝚙𝚎𝚗𝚅𝙿𝙽 𝙲𝚘𝚗𝚏𝚒𝚐  :**
**https://{DOMAIN}:81/OpenVPN.zip**
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝       :**
**https://{DOMAIN}:81/ssh-{user}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{later}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_ssh_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

# TRIAL SSH
@bot.on(events.CallbackQuery(data=b'triall-ssh'))
async def triall_ssh(event):
  async def triall_ssh_(event):
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙳𝚞𝚛𝚊𝚝𝚒𝚘𝚗 [ 𝙴𝚡𝚊𝚖𝚙𝚕𝚎 : 1m / 1h ] : **")
      exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      exp = (await exp).raw_text
      if not (1 <= len(exp) <= 3):
         await event.edit("e.g., m 𝚏𝚘𝚛 𝚖𝚒𝚗𝚞𝚝𝚎𝚜, h 𝚏𝚘𝚛 𝚑𝚘𝚞𝚛𝚜", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "vmess")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝚃𝚛𝚒𝚊𝚕𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" "{ip}" | assh bot_triall'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝**")
    else:
      b = [x.group() for x in re.finditer("ssh://(.*)",a)]
      print(b)
      pw = re.search("#pw=(.*)#",b[0]).group(1)
      remark = re.search(f"{pw}#(.*)",b[0]).group(1)
      exp1 = re.search("ssh://(.*)#pw=",b[0]).group(1)
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨ 𝚂𝚂𝙷 𝙾𝚙𝚎𝚗𝚅𝙿𝙽 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     :** `{remark}`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{pw}`
**◇──────────────────────◇**
**» 🌀𝚄𝙳𝙿 𝙰𝚌𝚌𝚘𝚞𝚗𝚝   :**
`{DOMAIN}:54-65535@{remark}:{pw}`
**» 🌀𝚆𝚂𝚂 𝙰𝚌𝚌𝚘𝚞𝚗𝚝  :**
`{DOMAIN}:80@{remark}:{pw}`
**◇──────────────────────◇** 
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛           :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢             :** `{z["country"]}`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜        :** `{ip} IP`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗       :** `{DOMAIN}`
**» 𝙷𝚘𝚜𝚝 𝙽𝚂𝙳𝚘𝚖𝚊𝚒𝚗  :** `{ns}`
**» 𝙿𝚞𝚋 𝙺𝚎𝚢               :** `{pub}`
**◇──────────────────────◇**
**» 𝙿𝚘𝚛𝚝 𝚄𝙳𝙿 𝙲𝚞𝚜𝚝𝚘𝚖    :** `54-65535` 
**» 𝙿𝚘𝚛𝚝 𝚂𝚂𝙻 𝚃𝙻𝚂/𝚂𝙽𝙸    :** `443` 
**» 𝙿𝚘𝚛𝚝 𝚆𝚂𝚂 𝙽𝚃𝙻𝚂        :** `80, 8080`
**» 𝙿𝚘𝚛𝚝 𝙾𝚅𝙿𝙽                :** `443, 1194, 2200`
**» 𝙿𝚛𝚘𝚡𝚢 𝚂𝚚𝚞𝚒𝚍              :** `3128`
**» 𝙱𝚊𝚍𝚅𝙿𝙽 𝚄𝙳𝙿            :** `7100-7300`
**◇──────────────────────◇**
**⟨ 𝙿𝚊𝚢𝚕𝚘𝚊𝚍 𝚆𝚂  ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**◇──────────────────────◇**
**» 🌀𝙾𝚙𝚎𝚗𝚅𝙿𝙽 𝙲𝚘𝚗𝚏𝚒𝚐  :**
**https://{DOMAIN}:81/OpenVPN.zip**
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝       :**
**https://{DOMAIN}:81/ssh-{remark}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await triall_ssh_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

#CEK SSH
@bot.on(events.CallbackQuery(data=b'cek-ssh'))
async def cek_ssh(event):
  async def cek_ssh_(event):
    ssh_data_cmd = "cat /etc/ssh/.ssh.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(ssh_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/ssh/{akun} | awk '{{print $6}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
        exp_cmd = f'cat /etc/ssh/.ssh.db | grep "{akun}" | cut -d " " -f 3'
        exp1 = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        result_message += f"  {formatted_akun}   -   {exp1}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝙴𝚡𝚙𝚒𝚛𝚎𝚍**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    exp_cmd = f'cat /etc/ssh/.ssh.db | grep "{user}" | cut -d " " -f 3'
    iplim_cmd = f"cat /etc/ssh/{user} | awk '{{print $1}}'"
    pw_cmd = f"cat /etc/ssh/{user} | awk '{{print $2}}'"          
    exp1 = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
    ip1 = subprocess.check_output(iplim_cmd, shell=True, text=True).strip()
    pw = subprocess.check_output(pw_cmd, shell=True, text=True).strip() 
    msg = f"""
**◇──────────────────────◇**
**     ◇⟨ 𝚂𝚂𝙷 𝙾𝚙𝚎𝚗𝚅𝙿𝙽 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     :** `{user}`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{pw}`
**◇──────────────────────◇**
**» 🌀𝚄𝙳𝙿 𝙰𝚌𝚌𝚘𝚞𝚗𝚝   :**
`{DOMAIN}:54-65535@{user}:{pw}`
**» 🌀𝚆𝚂𝚂 𝙰𝚌𝚌𝚘𝚞𝚗𝚝  :**
`{DOMAIN}:80@{user}:{pw}`
**◇──────────────────────◇** 
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛           :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢             :** `{z["country"]}`
**» 𝙻𝚒𝚖𝚒𝚝 𝙰𝚍𝚛𝚎𝚜𝚜        :** `{ip1} IP`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗       :** `{DOMAIN}`
**» 𝙷𝚘𝚜𝚝 𝙽𝚂𝙳𝚘𝚖𝚊𝚒𝚗  :** `{ns}`
**» 𝙿𝚞𝚋 𝙺𝚎𝚢               :** `{pub}`
**◇──────────────────────◇**
**» 𝙿𝚘𝚛𝚝 𝚄𝙳𝙿 𝙲𝚞𝚜𝚝𝚘𝚖    :** `54-65535` 
**» 𝙿𝚘𝚛𝚝 𝚂𝚂𝙻 𝚃𝙻𝚂/𝚂𝙽𝙸    :** `443` 
**» 𝙿𝚘𝚛𝚝 𝚆𝚂𝚂 𝙽𝚃𝙻𝚂        :** `80, 8080`
**» 𝙿𝚘𝚛𝚝 𝙾𝚅𝙿𝙽                :** `443, 1194, 2200`
**» 𝙿𝚛𝚘𝚡𝚢 𝚂𝚚𝚞𝚒𝚍              :** `3128`
**» 𝙱𝚊𝚍𝚅𝙿𝙽 𝚄𝙳𝙿            :** `7100-7300`
**◇──────────────────────◇**
**⟨ 𝙿𝚊𝚢𝚕𝚘𝚊𝚍 𝚆𝚂  ⟩**
`GET / HTTP/1.1[crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]`
**◇──────────────────────◇**
**» 🌀𝙾𝚙𝚎𝚗𝚅𝙿𝙽 𝙲𝚘𝚗𝚏𝚒𝚐  :**
**https://{DOMAIN}:81/OpenVPN.zip**
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝       :**
**https://{DOMAIN}:81/ssh-{user}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚑𝚎𝚌𝚔 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
    
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await cek_ssh_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

#LOGIN SSH
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
  async def login_ssh_(event):
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = 'ssh.mt login'.strip()
    x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
    print(x)
    z = subprocess.check_output(cmd, shell=True).decode("utf-8")
    await event.respond(f"""
{z}
""",buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await login_ssh_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

#Delete SSH
@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
  async def delete_ssh_(event):
    ssh_data_cmd = "cat /etc/ssh/.ssh.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(ssh_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        exp_cmd = f'cat /etc/ssh/.ssh.db | grep "{akun}" | cut -d " " -f 3'
        exp1 = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        result_message += f"  {formatted_akun}   -   {exp1}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝙴𝚡𝚙𝚒𝚛𝚎𝚍**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙳𝚎𝚕𝚎𝚝𝚎𝚍 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'ktriall ssh {user}'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝙳𝚎𝚕𝚎𝚝𝚎 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await delete_ssh_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

#Renew SSH
@bot.on(events.CallbackQuery(data=b'renew-ssh-all'))
async def ren_ssh_all(event):
  async def ren_ssh_all_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚙𝚍𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" "{ip}" | assh renew {user} all'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond(f"** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      exp_command = f'cat /etc/ssh/.ssh.db | grep "{user}" | cut -d " " -f 3'
      exp1 = subprocess.check_output(exp_command, shell=True).decode("ascii").strip()
      iplim_command = f'cat "/etc/ssh/{user}" | awk \'{{print $1}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚁𝚎𝚗𝚎𝚠 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 :** `{ip1} 𝙸𝙿`
**» 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙾𝚗 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_ssh_all_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'renew-ssh-exp'))
async def ren_ssh_exp(event):
  async def ren_ssh_exp_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚙𝚍𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" | assh renew {user} exp'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond(f"** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      exp_command = f'cat /etc/ssh/.ssh.db | grep "{user}" | cut -d " " -f 3'
      exp1 = subprocess.check_output(exp_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚁𝚎𝚗𝚎𝚠 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙾𝚗 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_ssh_exp_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
 
@bot.on(events.CallbackQuery(data=b'renew-ssh-lim'))
async def ren_ssh_db(event):
  async def ren_ssh_db_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    async with bot.conversation(chat) as ip:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 [𝙰𝚍𝚛𝚎𝚜𝚜] ( 𝚖𝚊𝚡 𝟹 𝚍𝚒𝚐𝚒𝚝𝚜 ) : **")
      ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      ip = (await ip).raw_text
      if not (1 <= len(ip) <= 3):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝙽𝚞𝚖𝚋𝚎𝚛!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝟸 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚙𝚍𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{ip}" | assh renew {user} db'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond(f"** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      iplim_command = f'cat "/etc/ssh/{user}" | awk \'{{print $1}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚁𝚎𝚗𝚎𝚠 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 𝙻𝚒𝚖𝚒𝚝 𝙸𝙿 :** `{ip1} 𝙸𝙿`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_ssh_db_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'lok-ssh'))
async def lok_ssh(event):
  async def lok_ssh_(event):
    ssh_data_cmd = "cat /etc/ssh/.ssh.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(ssh_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/ssh/{akun} | awk '{{print $3}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        formatted_status = f"{status: <{5}}"
        result_message += f"  {formatted_akun}   -   {formatted_status}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝚂𝚝𝚊𝚝𝚞𝚜**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙻𝚘𝚌𝚔𝚎𝚍 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'assh lock {user}'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝙻𝚘𝚌𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await lok_ssh_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
    
@bot.on(events.CallbackQuery(data=b'unlok-ssh'))
async def unlok_ssh(event):
  async def unlok_ssh_(event):
    ssh_data_cmd = "cat /etc/ssh/.ssh.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(ssh_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/ssh/{akun} | awk '{{print $3}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        formatted_status = f"{status: <{5}}"
        result_message += f"  {formatted_akun}   -   {formatted_status}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝚂𝚝𝚊𝚝𝚞𝚜**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "ssh")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚗𝚕𝚘𝚌𝚔𝚎𝚍 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'assh unlock {user}'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚄𝚗𝚕𝚘𝚌𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","ssh")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await unlok_ssh_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
    
@bot.on(events.CallbackQuery(data=b'renew-ssh'))
async def renew_ssh(event):
  async def renew_ssh_(event):
    inline = [
[Button.inline("[ 𝙍𝙚𝙣𝙚𝙬 𝘼𝙡𝙡 ]","renew-ssh-all"),
Button.inline("[ 𝙍𝙚𝙣𝙚𝙬 𝙀𝙭𝙥 ]","renew-ssh-exp")],
[Button.inline("[ 𝙍𝙚𝙣𝙚𝙬 𝙇𝙞𝙢𝙞𝙩 [ 𝙄𝙋 ] ]","renew-ssh-lim")],
[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","menu")]]
    ssh_data_cmd = "cat /etc/ssh/.ssh.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(ssh_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        exp_cmd = f'cat /etc/ssh/.ssh.db | grep "{akun}" | cut -d " " -f 3'
        iplim_cmd = f"cat /etc/ssh/{akun} | awk '{{print $2}}'"    
        exp = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
        iplim = subprocess.check_output(iplim_cmd, shell=True, text=True).strip()          
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        formatted_iplim = f"{iplim: <{3}}"
        result_message += f"  {formatted_akun}  -  {exp}  -  {formatted_iplim} IP\n"
        await asyncio.sleep(0.2)  # Sleep for 0.2 seconds 
        # Kirim pesan dengan hasil yang dikumpulkan
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎   |   𝙴𝚡𝚙   |  𝙸𝙿 𝙰𝚍𝚛𝚎𝚜𝚜**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(2)
      await event.edit(msg, buttons=inline)   
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await renew_ssh_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
  async def ssh_(event):
    inline = [
[Button.inline("[ 𝘾𝙧𝙚𝙖𝙩𝙚 𝙎𝙎𝙃 ]","create-ssh"),
Button.inline("[ 𝙏𝙧𝙞𝙖𝙡𝙡 𝙎𝙎𝙃 ]","triall-ssh")],
[Button.inline("[ 𝘿𝙚𝙡𝙚𝙩𝙚 𝙎𝙎𝙃 ]","delete-ssh"),
Button.inline("[ 𝙍𝙚𝙣𝙚𝙬 𝙎𝙎𝙃 ]","renew-ssh")],
[Button.inline("[ 𝙇𝙤𝙘𝙠 𝙎𝙎𝙃 ]","lok-ssh"),
Button.inline("[ 𝙐𝙣𝙡𝙤𝙘𝙠 𝙎𝙎𝙃 ]","unlok-ssh")],
[Button.inline("[ 𝘾𝙝𝙚𝙘𝙠 𝙎𝙎𝙃 ]","cek-ssh"),
Button.inline("[ 𝙇𝙤𝙜𝙞𝙣 𝙎𝙎𝙃 ]","login-ssh")],
[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","menu")]]
    msg = f"""
**◇──────────────────────◇**
**    ◇⟨ 𝚂𝚂𝙷 𝙾𝚙𝚎𝚗𝚅𝙿𝙽 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 ⟩◇**
**◇──────────────────────◇**
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎   :** ` 𝚂𝚂𝙷, 𝚄𝙳𝙿, 𝙾𝚙𝚎𝚗𝚅𝙿𝙽, 𝚂𝚕𝚘𝚠𝙳𝙽𝚂`
**» 𝙳𝚘𝚖𝚊𝚒𝚗   :** `{DOMAIN}`
**» 𝙸𝚂𝙿 𝚅𝙿𝚂  :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢  :** `{z["country"]}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ssh_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

