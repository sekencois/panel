from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu|/start)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("[ 𝙎𝙎𝙃 𝙈𝙚𝙣𝙪 ]","ssh"),
Button.inline("[ 𝙉𝙤𝙤𝙗𝙯 𝙈𝙚𝙣𝙪 ]","noobzvpns")],
[Button.inline("[ 𝙑𝙢𝙚𝙨𝙨 𝙈𝙚𝙣𝙪 ]","vmess"),
Button.inline("[ 𝙑𝙡𝙚𝙨𝙨 𝙈𝙚𝙣𝙪 ]","vless")],
[Button.inline("[ 𝙏𝙧𝙤𝙟𝙖𝙣 𝙈𝙚𝙣𝙪 ]","trojan"),
Button.inline("[ 𝙎_𝙨𝙤𝙘𝙠𝙨 𝙈𝙚𝙣𝙪 ]","shadowsocks")],
[Button.inline("[ 𝙊𝙩𝙝𝙚𝙧𝙨 𝙎𝙚𝙩𝙩𝙞𝙣𝙜 ]","setting")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
		except:
			await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
	elif val == "true":
		ox = requests.get(f"https://ipv4.icanhazip.com").text.strip()
		nm= f" curl -sS https://raw.githubusercontent.com/Annnjayy/Multi/Auth/name | grep '{ox}'| cut -d ' ' -f3 "
		name = subprocess.check_output(nm, shell=True).decode("ascii").strip()
		xp= f" curl -sS https://raw.githubusercontent.com/Annnjayy/Multi/Auth/name | grep '{ox}'| cut -d ' ' -f4 "
		exp = subprocess.check_output(xp, shell=True).decode("ascii").strip()
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		nb = f' cat /etc/noobzvpns/.noobzvpns.db | grep "###" | wc -l'
		noob = subprocess.check_output(nb, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		s = f' cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l'
		ss = subprocess.check_output(s, shell=True).decode("ascii")
		hap = subprocess.call(["systemctl", "is-active", "--quiet", "haproxy"])
		if(hap == 0):
			hap1 = f'✔️'
		else:
			hap1 = f'✖️'
		ngx = subprocess.call(["systemctl", "is-active", "--quiet", "nginx"])
		if(ngx == 0):
			ngx1 = f'✔️'
		else:
			ngx1 = f'✖️'
		xr = subprocess.call(["systemctl", "is-active", "--quiet", "xray@vmess"])
		if(xr == 0):
			xr1 = f'✔️'
		else:
			xr1 - f'✖️'
		sh = subprocess.call(["systemctl", "is-active", "--quiet", "websocket"])
		if(sh == 0):
			ws1 = f'✔️'
		else:
			ws1 = f'✖️'
		msg = f"""
**✧◇────────────────────◇✧**
         **✰⟨ 𝗕𝗼𝘁 𝙈𝙖𝙠𝙝𝙡𝙪𝙠𝙏𝙪𝙣𝙣𝙚𝙡 ⟩✰**
**✧◇────────────────────◇✧**
     **  𝙷𝙰𝙿𝚁𝙾𝚇𝚈  :**  `{hap1}`      ** 𝚇𝚁𝙰𝚈     :**  `{xr1}`
     **  𝚆𝚂-𝚂𝙾𝙲𝙺  :**  `{ws1}`        **𝙽𝙶𝙸𝙽𝚇   :**  `{ngx1}` 
**✧◇────────────────────◇✧**
              **✰⟨ 𝗧𝗼𝘁𝗮𝗹 𝘼𝙘𝙘𝙤𝙪𝙣𝙩 ⟩✰**
**✧◇────────────────────◇✧**
** » 𝚂𝚂𝙷 𝙾𝚅𝙿𝙽         :** `{ssh.strip()}`
** » 𝚂𝚂𝙷 𝙽𝚘𝚘𝚋𝚣        :** `{noob.strip()}`
** » 𝚇𝚁𝙰𝚈 𝚅𝙼𝙴𝚂𝚂    :** `{vms.strip()}`
** » 𝚇𝚁𝙰𝚈 𝚅𝙻𝙴𝚂𝚂     :** `{vls.strip()}`
** » 𝚇𝚁𝙰𝚈 𝚃𝚁𝙾𝙹𝙰𝙽  :** `{trj.strip()}`
** » 𝚇𝚁𝙰𝚈 𝚂-𝚂𝙾𝙲𝙺𝚂 :** `{ss.strip()}`
**✧◇────────────────────◇✧**
** » 𝙱𝚘𝚝 𝚅𝚎𝚛𝚜𝚒𝚘𝚗   :** `v2.3` 
** » 𝚄𝚜𝚎𝚛 𝚂𝚌𝚛𝚒𝚙𝚝  :** `{name.strip()}`
** » 𝙴𝚡𝚙 𝚂𝚌𝚛𝚒𝚙𝚝    :** `{exp.strip()}`
**✧◇────────────────────◇✧**
** » 𝙰𝚍𝚖𝚒𝚗 :** `@{sender.username}` 
** » 𝚄𝚙𝚝𝚒𝚖𝚎 :** `{get_uptime()}`
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)