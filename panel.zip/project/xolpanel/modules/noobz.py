from xolpanel import *

#CRATE noobzvpns
@bot.on(events.CallbackQuery(data=b'create-noobzvpns'))
async def create_noobzvpns(event):
  async def create_noobzvpns_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    async with bot.conversation(chat) as pw:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
      if not (2 <= len(pw) <= 8):
         await event.respond(f" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond("** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("` 𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" | anoob bot_add'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝**")
    else:
      today = DT.date.today()
      later = today + DT.timedelta(days=int(exp))
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨ 𝚂𝚂𝙷 𝙽𝚘𝚘𝚋𝚣𝚅𝙿𝙽𝚂 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     :** `{user}`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{pw}`
**◇──────────────────────◇** 
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛      :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢        :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**◇──────────────────────◇**
**» 𝚃𝙲𝙿_𝚂𝚃𝙳    :** `8880` 
**» 𝚃𝙲𝙿_𝚂𝚂𝙻    :** `8433` 
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝       :**
**https://{DOMAIN}:81/noobz-{user}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{later}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","noobzvpns")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await create_noobzvpns_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

# TRIAL noobzvpns
@bot.on(events.CallbackQuery(data=b'triall-noobzvpns'))
async def triall_noobzvpns(event):
  async def triall_noobzvpns_(event):
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 𝙳𝚞𝚛𝚊𝚝𝚒𝚘𝚗 [ 𝙴𝚡𝚊𝚖𝚙𝚕𝚎 : 1m / 1h ] : **")
      exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      exp = (await exp).raw_text
      if not (1 <= len(exp) <= 3):
         await event.edit("e.g., m 𝚏𝚘𝚛 𝚖𝚒𝚗𝚞𝚝𝚎𝚜, h 𝚏𝚘𝚛 𝚑𝚘𝚞𝚛𝚜", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "vmess")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚛𝚊𝚝𝚎 𝚃𝚛𝚒𝚊𝚕𝚕 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" | anoob bot_triall'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙰𝚕𝚛𝚎𝚊𝚍𝚢 𝙴𝚡𝚒𝚜𝚝**")
    else:
      b = [x.group() for x in re.finditer("noobz://(.*)",a)]
      print(b)
      pw = re.search("#pw=(.*)#",b[0]).group(1)
      remark = re.search(f"{pw}#(.*)",b[0]).group(1)
      exp1 = re.search("noobz://(.*)#pw=",b[0]).group(1)
      msg = f"""
**◇──────────────────────◇**
**     ◇⟨ 𝚂𝚂𝙷 𝙽𝚘𝚘𝚋𝚣𝚅𝙿𝙽𝚂 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     :** `{remark}`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{pw}`
**◇──────────────────────◇**
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛      :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢        :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**◇──────────────────────◇**
**» 𝚃𝙲𝙿_𝚂𝚃𝙳    :** `8880` 
**» 𝚃𝙲𝙿_𝚂𝚂𝙻    :** `8433` 
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝       :**
**https://{DOMAIN}:81/noobz-{remark}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","noobzvpns")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await triall_noobzvpns_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

#CEK noobzvpns
@bot.on(events.CallbackQuery(data=b'cek-noobzvpns'))
async def cek_noobzvpns(event):
  async def cek_noobzvpns_(event):
    noobzvpns_data_cmd = "cat /etc/noobzvpns/.noobzvpns.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(noobzvpns_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/noobzvpns/{akun} | awk '{{print $6}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
        exp_cmd = f'cat /etc/noobzvpns/.noobzvpns.db | grep "{akun}" | cut -d " " -f 3'
        exp1 = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        result_message += f"  {formatted_akun}   -   {exp1}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝙴𝚡𝚙𝚒𝚛𝚎𝚍**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    exp_cmd = f'cat /etc/noobzvpns/.noobzvpns.db | grep "{user}" | cut -d " " -f 3'
    pw_cmd = f"cat /etc/noobzvpns/{user} | awk '{{print $2}}'"          
    exp1 = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
    pw = subprocess.check_output(pw_cmd, shell=True, text=True).strip() 
    msg = f"""
**◇──────────────────────◇**
**     ◇⟨ 𝚂𝚂𝙷 𝙽𝚘𝚘𝚋𝚣𝚅𝙿𝙽𝚂 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     :** `{user}`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍     :** `{pw}`
**◇──────────────────────◇**
**» 𝙿𝚛𝚘𝚟𝚒𝚍𝚎𝚛      :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢        :** `{z["country"]}`
**» 𝙷𝚘𝚜𝚝 𝙳𝚘𝚖𝚊𝚒𝚗  :** `{DOMAIN}`
**◇──────────────────────◇**
**» 𝚃𝙲𝙿_𝚂𝚃𝙳    :** `8880` 
**» 𝚃𝙲𝙿_𝚂𝚂𝙻    :** `8433` 
**◇──────────────────────◇**
**» 🌀𝙻𝚒𝚗𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝       :**
**https://{DOMAIN}:81/noobz-{user}.txt**
**◇──────────────────────◇**
**» 🌀𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝚄𝚗𝚝𝚒𝚕 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙲𝚑𝚎𝚌𝚔 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","noobzvpns")]])
    
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await cek_noobzvpns_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

#Delete noobzvpns
@bot.on(events.CallbackQuery(data=b'delete-noobzvpns'))
async def delete_noobzvpns(event):
  async def delete_noobzvpns_(event):
    noobzvpns_data_cmd = "cat /etc/noobzvpns/.noobzvpns.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(noobzvpns_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        exp_cmd = f'cat /etc/noobzvpns/.noobzvpns.db | grep "{akun}" | cut -d " " -f 3'
        exp1 = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        result_message += f"  {formatted_akun}   -   {exp1}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝙴𝚡𝚙𝚒𝚛𝚎𝚍**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.respond(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙳𝚎𝚕𝚎𝚝𝚎𝚍 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'ktriall noobz {user}'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝙳𝚎𝚕𝚎𝚝𝚎 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","noobzvpns")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await delete_noobzvpns_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

#Renew noobzvpns
@bot.on(events.CallbackQuery(data=b'renew-noobzvpns-all'))
async def ren_noobzvpns_all(event):
  async def ren_noobzvpns_all_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚙𝚍𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" | anoob renew {user} all'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond(f"** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      exp_command = f'cat /etc/noobzvpns/.noobzvpns.db | grep "{user}" | cut -d " " -f 3'
      exp1 = subprocess.check_output(exp_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚁𝚎𝚗𝚎𝚠 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙾𝚗 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","noobzvpns")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_noobzvpns_all_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'renew-noobzvpns-exp'))
async def ren_noobzvpns_exp(event):
  async def ren_noobzvpns_exp_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    async with bot.conversation(chat) as exp:
      await event.respond(f"** 𝙲𝚑𝚘𝚘𝚜𝚎 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙳𝚊𝚢 **",buttons=[
[Button.inline("• 𝟽 𝙳𝚊𝚢 •","7"),
Button.inline("• 𝟷𝟻 𝙳𝚊𝚢 •","15")],
[Button.inline("• 𝟹𝟶 𝙳𝚊𝚢 •","30"),
Button.inline("• 𝟼𝟶 𝙳𝚊𝚢 •","60")]])
      exp = exp.wait_event(events.CallbackQuery)
      exp = (await exp).data.decode("ascii")
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚙𝚍𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{exp}" | anoob renew {user} exp'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond(f"** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      exp_command = f'cat /etc/noobzvpns/.noobzvpns.db | grep "{user}" | cut -d " " -f 3'
      exp1 = subprocess.check_output(exp_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚁𝚎𝚗𝚎𝚠 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 𝙴𝚡𝚙𝚒𝚛𝚎𝚍 𝙾𝚗 :** `{exp1}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","noobzvpns")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_noobzvpns_exp_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
 
@bot.on(events.CallbackQuery(data=b'renew-noobzvpns-pw'))
async def ren_noobzvpns_db(event):
  async def ren_noobzvpns_db_(event):
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    async with bot.conversation(chat) as pw:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      pw = (await pw).raw_text
      if not (2 <= len(pw) <= 8):
         await event.respond(f" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚙𝚍𝚊𝚝𝚎 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'printf "%s\n" "{pw}" | anoob renew {user} db'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond(f"** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      iplim_command = f'cat "/etc/noobzvpns/{user}" | awk \'{{print $1}}\''
      ip1 = subprocess.check_output(iplim_command, shell=True).decode("ascii").strip()
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚁𝚎𝚗𝚎𝚠 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 𝙿𝚊𝚜𝚜𝚠𝚘𝚛𝚍 :** `{ip1} 𝙸𝙿`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","noobzvpns")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await ren_noobzvpns_db_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

@bot.on(events.CallbackQuery(data=b'lok-noobzvpns'))
async def lok_noobzvpns(event):
  async def lok_noobzvpns_(event):
    noobzvpns_data_cmd = "cat /etc/noobzvpns/.noobzvpns.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(noobzvpns_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/noobzvpns/{akun} | awk '{{print $3}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        formatted_status = f"{status: <{5}}"
        result_message += f"  {formatted_akun}   -   {formatted_status}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝚂𝚝𝚊𝚝𝚞𝚜**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝙻𝚘𝚌𝚔𝚎𝚍 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'anoob lock {user}'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝙻𝚘𝚌𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","noobzvpns")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await lok_noobzvpns_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
    
@bot.on(events.CallbackQuery(data=b'unlok-noobzvpns'))
async def unlok_noobzvpns(event):
  async def unlok_noobzvpns_(event):
    noobzvpns_data_cmd = "cat /etc/noobzvpns/.noobzvpns.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(noobzvpns_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        status_cmd = f"cat /etc/noobzvpns/{akun} | awk '{{print $3}}'"
        status = subprocess.check_output(status_cmd, shell=True, text=True).strip()
         # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        formatted_status = f"{status: <{5}}"
        result_message += f"  {formatted_akun}   -   {formatted_status}\n"
        await asyncio.sleep(0.2)
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎     |   𝚂𝚝𝚊𝚝𝚞𝚜**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(1)
      await event.edit(msg)
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
    async with bot.conversation(chat) as user:
      await event.respond(f"** 🌀𝙸𝚗𝚙𝚞𝚝 [𝙲𝚕𝚒𝚎𝚗𝚝] 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 ( 𝚖𝚊𝚡 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜 ) : **")
      user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
      user = (await user).raw_text
      if not (2 <= len(user) <= 8):
         await event.edit(" 𝙾𝚗𝚕𝚢 𝟾 𝚌𝚑𝚊𝚛𝚊𝚌𝚝𝚎𝚛𝚜!!! 𝚃𝚛𝚢 𝚊𝚐𝚊𝚒𝚗 [ 𝚎𝚡𝚊𝚖𝚙𝚕𝚎 : 𝚖𝚎𝚑𝚘𝚗𝚔𝟽𝟼 ]", buttons=[[Button.inline("[ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ]", "noobzvpns")]])
         return
    await event.edit("`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐 𝚄𝚗𝚕𝚘𝚌𝚔𝚎𝚍 𝙿𝚛𝚎𝚖𝚒𝚞𝚖 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    await asyncio.sleep(1)

    for _ in range(10):  # Ubah jumlah iterasi sesuai kebutuhan
        await asyncio.sleep(0.1)  # Ubah durasi tidur sesuai kebutuhan
        progress = "▰" * _ + "▱" * (10 - _)
        await event.edit(f"`𝙿𝚛𝚘𝚌𝚎𝚜𝚜𝚒𝚗𝚐...`\n{progress}")

    await event.edit("`𝚆𝚊𝚒𝚝... 𝚂𝚎𝚝𝚝𝚒𝚗𝚐 𝚞𝚙 𝚊𝚗 𝙰𝚌𝚌𝚘𝚞𝚗𝚝`")
    cmd = f'anoob unlock {user}'
    try:
      a = subprocess.check_output(cmd, shell=True).decode("utf-8")
    except:
      await event.respond("** 𝚄𝚜𝚎𝚛 𝙽𝚘𝚝 𝙵𝚘𝚞𝚗𝚍 **")
    else:
      msg = f"""
**◇──────────────────────◇**
**  ◇⟨ 𝚂𝚞𝚌𝚌𝚎𝚜 𝚄𝚗𝚕𝚘𝚌𝚔 𝙰𝚌𝚌𝚘𝚞𝚗𝚝 ⟩◇**
**◇──────────────────────◇**
**» 𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎 :** `{user}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.respond(msg,buttons=[[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","noobzvpns")]])
  chat = event.chat_id
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await unlok_noobzvpns_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)
    
@bot.on(events.CallbackQuery(data=b'renew-noobzvpns'))
async def renew_noobzvpns(event):
  async def renew_noobzvpns_(event):
    inline = [
#[Button.inline("[ 𝙍𝙚𝙣𝙚𝙬 𝘼𝙡𝙡 ]","renew-noobzvpns-all"),
[Button.inline("[ 𝙍𝙚𝙣𝙚𝙬 𝙀𝙭𝙥 ]","renew-noobzvpns-exp"),
Button.inline("[ 𝙍𝙚𝙣𝙚𝙬 𝙋𝙖𝙨𝙨𝙬𝙤𝙧𝙙 ]","renew-noobzvpns-lim")],
[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","menu")]]
    noobzvpns_data_cmd = "cat /etc/noobzvpns/.noobzvpns.db | grep '^###' | cut -d ' ' -f 2 | sort | uniq"
    try:
      data = subprocess.check_output(noobzvpns_data_cmd, shell=True, text=True).splitlines()
      result_message = ""
      for akun in data:
        exp_cmd = f'cat /etc/noobzvpns/.noobzvpns.db | grep "{akun}" | cut -d " " -f 3'
        exp = subprocess.check_output(exp_cmd, shell=True, text=True).strip()
        # Kumpulkan hasilnya dalam satu string
        formatted_akun = f"{akun: <{10}}"
        result_message += f"  {formatted_akun}  -  {exp}  \n"
        await asyncio.sleep(0.2)  # Sleep for 0.2 seconds 
        # Kirim pesan dengan hasil yang dikumpulkan
      msg = f"""
**◇──────────────────────◇**
**  𝚄𝚜𝚎𝚛𝚗𝚊𝚖𝚎   |   𝙴𝚡𝚙𝚒𝚛𝚎𝚍**
**◇──────────────────────◇**
{result_message}
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
      await event.edit(" 𝚆𝚊𝚒𝚝 𝚜𝚎𝚊𝚛𝚌𝚑𝚒𝚗𝚐...")
      await asyncio.sleep(2)
      await event.edit(msg, buttons=inline)   
    except subprocess.CalledProcessError as e:
      await event.answer(" 𝙴𝚛𝚛𝚘𝚛 𝚎𝚡𝚎𝚌𝚞𝚝𝚒𝚗𝚐 𝚌𝚘𝚖𝚖𝚊𝚗𝚍 ", alert=True)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await renew_noobzvpns_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

#@bot.on(events.NewMessage(pattern="/noobz"))
@bot.on(events.CallbackQuery(data=b'noobzvpns'))
async def noobzvpns(event):
  async def noobzvpns_(event):
    inline = [
[Button.inline("[ 𝘾𝙧𝙚𝙖𝙩𝙚 𝙉𝙤𝙤𝙗𝙯 ]","create-noobzvpns"),
Button.inline("[ 𝙏𝙧𝙞𝙖𝙡𝙡 𝙉𝙤𝙤𝙗𝙯 ]","triall-noobzvpns")],
[Button.inline("[ 𝘿𝙚𝙡𝙚𝙩𝙚 𝙉𝙤𝙤𝙗𝙯 ]","delete-noobzvpns"),
Button.inline("[ 𝙍𝙚𝙣𝙚𝙬 𝙉𝙤𝙤𝙗𝙯 ]","renew-noobzvpns")],
[Button.inline("[ 𝙇𝙤𝙘𝙠 𝙉𝙤𝙤𝙗𝙯 ]","lok-noobzvpns"),
Button.inline("[ 𝙐𝙣𝙡𝙤𝙘𝙠 𝙉𝙤𝙤𝙗𝙯 ]","unlok-noobzvpns")],
[Button.inline("[ 𝘾𝙝𝙚𝙘𝙠 𝙉𝙤𝙤𝙗𝙯 ]","cek-noobzvpns")],
#Button.inline("[ 𝙇𝙤𝙜𝙞𝙣 𝙉𝙤𝙤𝙗𝙯 ]","login-noobzvpns")],
[Button.inline("‹ 𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪 ›","menu")]]
    msg = f"""
**◇──────────────────────◇**
**    ◇⟨ 𝚂𝚂𝙷 𝙽𝚘𝚘𝚋𝚣𝚅𝙿𝙽𝚂 𝙼𝙰𝙽𝙰𝙶𝙴𝚁 ⟩◇**
**◇──────────────────────◇**
**» 𝚂𝚎𝚛𝚟𝚒𝚌𝚎   :** `𝙽𝚘𝚘𝚋𝚣𝚅𝙿𝙽𝚂`
**» 𝙳𝚘𝚖𝚊𝚒𝚗   :** `{DOMAIN}`
**» 𝙸𝚂𝙿 𝚅𝙿𝚂  :** `{z["isp"]}`
**» 𝙲𝚘𝚞𝚗𝚝𝚛𝚢  :** `{z["country"]}`
**» 🤖@sshxvpn**
**◇──────────────────────◇**
"""
    await event.edit(msg,buttons=inline)
  sender = await event.get_sender()
  a = valid(str(sender.id))
  if a == "true":
    await noobzvpns_(event)
  else:
    await event.answer("𝙰𝚔𝚜𝚎𝚜 𝙳𝚒𝚝𝚘𝚕𝚊𝚔", alert=True)

